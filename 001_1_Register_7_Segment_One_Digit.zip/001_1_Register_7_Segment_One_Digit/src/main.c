
#include "stm32f4xx.h"
#include "stm32f4_discovery.h"

int dig1 = 0;

void CLK_Config()
{
	RCC->CR |= 0X00030000;  //HSEON and HSEONRDY enable
	while (!(RCC->CR & 0X00020000));  //HSEON Ready Flag wait
	RCC->CR |= 0X00080000;		// CSS enable
	RCC->PLLCFGR |= 0x00400000;	// PLL e HSE se�tik
	RCC->PLLCFGR |= 0X00000004;	//PLL M = 4
	RCC->PLLCFGR |= 0X00005A00;	//PLL N = 168
	RCC->PLLCFGR |= 0X00000000;	//PLL p = 2
	RCC->CFGR |= 0X00000000;	//AHB Prescaler = 1
	RCC->CFGR |= 0X00080000;	//APB2 Prescaler = 2
	RCC->CFGR |= 0X00001400;	//APB1 Prescaler = 4
	RCC->CIR |= 0X00080000;		//HSERDY Flag clear
	RCC->CIR |= 0X00800000;		//CSS Flag clear

}


void GPIO_Config()
{
	RCC->AHB1ENR = 0X00000002;	//GPIO B port clock enable

	GPIOB->MODER = 0X00001555;  // GPIOB_Port_0-1-2-3-4-5-6 select output mode
	GPIOB->OTYPER = 0X00000000; // GPIOB_Port_0-1-2-3-4-5-6 select Push-Pull
	GPIOB->PUPDR = 0X00000000;  // GPIOB Port No Pull-up No Pull-Down
	GPIOB->OSPEEDR = 0X00003FFF; // GPIOB_Port_0-1-2-3-4-5-6 select Very high speed


}

void Delay(uint32_t time)
{
	while (time--) ;
}

void Ones_Digit_Count()
{
	if (dig1 == 0)
	{
		Delay (0);
	}
	else
	{
		Delay(33600000);
	}

	dig1++;

	switch (dig1)
	{
		case 0:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X0000003F;  //GPIOB_Port 0-1-2-3-4-5 set, Port 6 reset (Segment A-B-C-D-E-F active, Segment G passive)
			break;
		}
		case 1:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X0000110;
			break;
		}
		case 2:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1011011;
			break;
		}
		case 3:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1001111;
			break;
		}
		case 4:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1100110;
			break;
		}
		case 5:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1101101;
			break;
		}
		case 6:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1111101;
			break;
		}
		case 7:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X0000111;
			break;
		}
		case 8:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1111111;
			break;
		}
		case 9:
		{
			GPIOB->ODR = 0X00000000;
			GPIOB->ODR = 0X1101111;
			break;
		}
		default :
		{
			dig1 = 0;
			break;
		}
	}

}


int main(void)
{
	CLK_Config();
	GPIO_Config();


  while (1)
  {
	  Ones_Digit_Count();
  }
}


void EVAL_AUDIO_TransferComplete_CallBack(uint32_t pBuffer, uint32_t Size){
  /* TODO, implement your code here */
  return;
}


uint16_t EVAL_AUDIO_GetSampleCallBack(void){
  /* TODO, implement your code here */
  return -1;
}
